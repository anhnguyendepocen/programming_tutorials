# 03: for-Loops and Custom Functions

## Concepts covered:
* for-loops
* custom functions and modules

## Project structure

### src
Contains tutorial script and source code to downlaod data required for this project
