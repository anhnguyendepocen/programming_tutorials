# 01: Intro to Python

## Concepts covered:

* Spyder
* Simple operations
* Data types
* Packages
* Reading in data
* Basic plotting

## Project structure

### data
Contains raw data used for this project. DO NOT EDIT

### src
Contains tutorial script and soource code to downlaod data required for this project
