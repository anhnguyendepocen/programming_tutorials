# 03: Numerical Python and Conditions

## Concepts covered:
* Numerical Python using NumPy
* Conditions and if-statements
* Arrays and conditions in data analysis

## Project structure

### data

#### /raw:
Contains raw data used for this project. DO NOT EDIT  
Directory where processed data will be stored.

### src
Contains tutorial script and source code to downlaod data required for this project
