#### 05: Project organization

## Concepts covered:

* Best practices  
  * File organization  
  * Documentation  
  * Workflow  
* Version control with Git (and GitHub)

## Project structure

### master.R
Simple project to compare SST from gliders and satellites

### src
Contains supplemental R functions required for this project
