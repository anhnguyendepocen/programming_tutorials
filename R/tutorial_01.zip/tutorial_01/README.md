# 01: Intro to R

## Concepts covered:

* Tour of Rstudio  
* Simple operations (R as a calculator)  
* Data types  
* Introduction to functions  
* Reading in data  
* Basic plotting  

## Project structure

### data
Contains raw data used for this project. DO NOT EDIT

### 01.R
Master script for this tutorial  

### src
Contains any supplemental R 'source' code required for this project
